'''
    HELLO

    Your task is to read a line containing a string S, and to print
    the string "Hello " followed by S followed by ".".

    Example:

       Input:  World

       Output: Hello World.
'''



print('Hello '+input()+'.')

